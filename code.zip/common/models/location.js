module.exports = function(Location) {

};
